/**
 * 
 */
package notfast.core;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Notorious F.A.S.T.
 * 2016/06/05
 * A receiver puts received data on a queue for retrieval by a queue handler thread
 */
public class Receiver {

	private BlockingQueue<String> queue = new LinkedBlockingQueue<String>();
	
	/**
	 * Called when a piece of data arrived from the data source.
	 * @param data
	 */
	public void onData(String data)
	{
		try {
			queue.put(data);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Engine main
	 * @param args
	 */
	public static void main(String[] args) {

		// A blocking queue is set up for each data source.
		// Each queue is serviced by a pair of receiver and queue handler threads.
		
		// For each data source, 
		//   DataSource twitter = new TwitterDataSource(new Receiver());
		//   DataSource twochan = new TwochanDataSource(new Receiver());
		// so that onData() is called per arrival of piece of data from the datasource.
	}
}
