/**
 * 
 */
package kobu.notfast;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Notorious F.A.S.T.
 * @author Abun
 * 2016/06/05
 * 2016/06/18 takePrioritydata
 */
public class Worker implements Runnable {

	private BlockingQueue<String> queue;
	
	public Worker(BlockingQueue<String> q)
	{
		queue = q;
	}
	
	public void run()
	{
		while (true)
		{
			try {
				String s = queue.take();
				String p = takePriorityData(s);
				if (p != null) passByMultiCast(p);
				saveData(s);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private String takePriorityData(String s)
	{
		// check if the data contains any high-priority data, if so extract that part and return to the caller
		return null;
	}
	
	private void passByMultiCast(String p)
	{
		// pass the high-priority data to the clients with multicast
	}
	
	private ExecutorService executor = Executors.newCachedThreadPool();

	private void saveData(String s)
	{
		// get a worker thread from the thread poll
		// let the Saver do the rest of the work
		Saver saver = new Saver(s);
		executor.execute(saver);
	}
}
