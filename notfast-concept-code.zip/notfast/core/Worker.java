package notfast.core;

/**
 * Notorious F.A.S.T.
 * 2016/06/18
 * 
 * A worker thread handles a piece of data; sends ergent items and saves the rest.
 */
public class Worker implements Runnable {
	
	private String data;
	
	Worker(String s)
	{
		data = s;
	}
	
	/**
	 * hanlde a piece of data and done.
	 */
	public void run()
	{
		String p = takePriorityData(data);
		if (p != null) passByMultiCast(p);
		saveData(data);
	}
	
	/**
	 * extract high-priority items within the data
	 * @param s entire data
	 * @return high-priority data or null if none included
	 */
	private String takePriorityData(String s)
	{
		return null;
	}
	
	/**
	 * pass the high-priority data to the clients with multicast
	 * @param p
	 */
	private void passByMultiCast(String p)
	{
		// every display application will be immediately notified the emergent data so that it can display it as soon as possible.
		// other non-important data can be display later on demand when the user actually needs that information.
	}

	/**
	 * store the entire data to the data store.
	 * @param s
	 */
	private void saveData(String s)
	{
		// data store may include:
		// - big data KVS like Hadoop, Google big table, Amazon data store
		// - memory cache like memcache, redis, etc.
		// - traditional relational databases.
	}

}
