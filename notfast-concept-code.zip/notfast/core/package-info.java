/**
 * Notorious F.A.S.T.
 * 2016/06/05
 */
/**
 * Core package of Notorious F.A.S.T.
 * High-speed, high-volume big data plumbing engine
 */
package notfast.core;