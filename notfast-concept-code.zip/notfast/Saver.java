package kobu.notfast;

/**
 * Notorious F.A.S.T.
 * @author Abun
 * 2016/06/18
 */
public class Saver implements Runnable {
	
	private String data;
	
	Saver(String s)
	{
		data = s;
	}
	
	public void run()
	{
		save();
	}
	
	private void save()
	{
		// save 'data' into the data store
	}
}
