/**
 * 
 */
package kobu.notfast;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Notorious F.A.S.T.
 * @author Abun
 * 2016/06/05
 */
public class Receiver {

	private BlockingQueue<String> queue = new LinkedBlockingQueue<String>();
	
	public void onData(String data)
	{
		try {
			queue.put(data);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// run Worker
		// exec Receiver
	}

}
