/**
 * 
 */
package notfast.core;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Notorious F.A.S.T.
 * 2016/06/05 Written
 * 2016/06/18 takePrioritydata
 * 
 * A queue handler services a blocking queue assigned to a data source.
 * On each piece of data queued, it spawns a worker thread to handle the data.
 */
public class Handler implements Runnable {

	private BlockingQueue<String> queue;
	
	private ExecutorService executor = Executors.newCachedThreadPool();

	public Handler(BlockingQueue<String> q)
	{
		queue = q;
	}

	/**
	 * queue handler thread loop; get a thread from the thread pool to run a worker
	 */
	public void run()
	{
		while (true)
		{
			try {
				String s = queue.take();
				Worker worker = new Worker(s);
				executor.execute(worker);
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
