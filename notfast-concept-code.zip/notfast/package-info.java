/**
 * Notorious F.A.S.T.
 * @author Abun
 * 2016/06/05
 */
/**
 * Core package of Notorious F.A.S.T.
 * big data plumbing engine
 */
package kobu.notfast;